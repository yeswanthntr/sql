CREATE DATABASE Veda_Northwind;

USE Veda_Northwind;
CREATE TABLE Customers (
    CustomerID VARCHAR(10) PRIMARY KEY,
    CompanyName VARCHAR(100),
    Country VARCHAR(50)
);
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50)
);
CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(50)
);
CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY,
    CompanyName VARCHAR(100)
);
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    UnitPrice DECIMAL(10,2),
    CategoryID INT,
    SupplierID INT,
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID),
    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID)
);
CREATE TABLE Shippers (
    ShipperID INT PRIMARY KEY,
    CompanyName VARCHAR(100)
);
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID VARCHAR(10),
    EmployeeID INT,
    OrderDate DATE,
    ShipVia INT,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
    FOREIGN KEY (ShipVia) REFERENCES Shippers(ShipperID)
);
CREATE TABLE `Order Details` (
    OrderID INT,
    ProductID INT,
    UnitPrice DECIMAL(10,2),
    Quantity INT,
    PRIMARY KEY (OrderID, ProductID),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);
INSERT INTO Customers VALUES
('C001', 'ABC Retail', 'India'),
('C002', 'Global Traders', 'Germany'),
('C003', 'Fresh Mart', 'USA'),
('C004', 'Tech World', 'UK'),
('C005', 'City Stores', 'India'),
('C006', 'New Customer', 'France');
INSERT INTO Employees VALUES
(1, 'John', 'Smith'),
(2, 'Mary', 'Johnson'),
(3, 'David', 'Brown'),
(4, 'Sarah', 'Wilson'),
(5, 'Robert', 'Taylor');
INSERT INTO Categories VALUES
(1, 'Electronics'),
(2, 'Beverages'),
(3, 'Food'),
(4, 'Stationery'),
(5, 'Furniture');
INSERT INTO Suppliers VALUES
(1, 'Tech Suppliers Ltd'),
(2, 'Global Foods Ltd'),
(3, 'Office Supplies Ltd'),
(4, 'Furniture World'),
(5, 'Fresh Products Ltd');
INSERT INTO Products VALUES
(1, 'Laptop', 75000.00, 1, 1),
(2, 'Mobile Phone', 25000.00, 1, 1),
(3, 'Coffee', 450.00, 2, 2),
(4, 'Tea', 300.00, 2, 2),
(5, 'Biscuits', 150.00, 3, 5),
(6, 'Notebook', 100.00, 4, 3),
(7, 'Office Chair', 5000.00, 5, 4),
(8, 'Desk', 12000.00, 5, 4);
INSERT INTO Shippers VALUES
(1, 'Fast Express'),
(2, 'Blue Dart'),
(3, 'Global Delivery');
INSERT INTO Orders VALUES
(101, 'C001', 1, '2026-01-10', 1),
(102, 'C002', 2, '2026-01-15', 2),
(103, 'C003', 1, '2026-02-05', 1),
(104, 'C001', 3, '2026-02-12', 3),
(105, 'C004', 4, '2026-03-01', 2),
(106, 'C005', 2, '2026-03-10', 1);
INSERT INTO `Order Details` VALUES
(101, 1, 75000.00, 1),
(101, 3, 450.00, 2),
(102, 2, 25000.00, 1),
(102, 4, 300.00, 3),
(103, 5, 150.00, 5),
(104, 6, 100.00, 10),
(105, 7, 5000.00, 2),
(106, 8, 12000.00, 1);
SELECT * FROM Customers;

SELECT * FROM Employees;

SELECT * FROM Categories;

SELECT * FROM Suppliers;

SELECT * FROM Products;

SELECT * FROM Shippers;

SELECT * FROM Orders;
---- 1
SELECT 
    c.CustomerID,
    c.CompanyName,
    o.OrderID,
    o.OrderDate
FROM Customers c
INNER JOIN Orders o
    ON c.CustomerID = o.CustomerID;


-- Orders and Employees
SELECT 
    o.OrderID,
    o.OrderDate,
    e.EmployeeID,
    e.FirstName,
    e.LastName
FROM Orders o
INNER JOIN Employees e
    ON o.EmployeeID = e.EmployeeID;
-- Products and Categories
SELECT 
    p.ProductID,
    p.ProductName,
    p.UnitPrice,
    c.CategoryName
FROM Products p
INNER JOIN Categories c
    ON p.CategoryID = c.CategoryID;
-- 4Orders, Customers and Employees
SELECT 
    o.OrderID,
    o.OrderDate,
    c.CompanyName,
    e.FirstName,
    e.LastName
FROM Orders o
INNER JOIN Customers c
    ON o.CustomerID = c.CustomerID
INNER JOIN Employees e
    ON o.EmployeeID = e.EmployeeID;


-- 5 
SELECT 
    c.CustomerID,
    c.CompanyName,
    o.OrderID,
    o.OrderDate
FROM Customers c
LEFT JOIN Orders o
    ON c.CustomerID = o.CustomerID;
    
-- 6
SELECT 
    c.CategoryID,
    c.CategoryName,
    p.ProductID,
    p.ProductName
FROM Categories c
LEFT JOIN Products p
    ON c.CategoryID = p.CategoryID;
 --- 7
 SELECT 
    c.CustomerID,
    c.CompanyName,
    c.Country,
    o.OrderID,
    o.OrderDate
FROM Customers c
INNER JOIN Orders o
    ON c.CustomerID = o.CustomerID
WHERE c.Country = 'Germany';

-- 8
SELECT 
    c.CustomerID,
    c.CompanyName,
    COUNT(o.OrderID) AS TotalOrders
FROM Customers c
LEFT JOIN Orders o
    ON c.CustomerID = o.CustomerID
GROUP BY 
    c.CustomerID,
    c.CompanyName
ORDER BY TotalOrders DESC;

-- 9
SELECT 
    o.OrderID,
    o.OrderDate,
    s.ShipperID,
    s.CompanyName AS ShipperName
FROM Orders o
INNER JOIN Shippers s
    ON o.ShipVia = s.ShipperID;
    
-- 10
SELECT 
    od.OrderID,
    p.ProductID,
    p.ProductName,
    od.Quantity,
    od.UnitPrice
FROM `Order Details` od
INNER JOIN Products p
    ON od.ProductID = p.ProductID;

-- 11
SELECT 
    o.OrderID,
    o.OrderDate,
    c.CompanyName AS CustomerName,
    s.CompanyName AS ShipperName
FROM Orders o
INNER JOIN Customers c
    ON o.CustomerID = c.CustomerID
INNER JOIN Shippers s
    ON o.ShipVia = s.ShipperID;
    
-- 12
SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    o.OrderID,
    o.OrderDate
FROM Employees e
LEFT JOIN Orders o
    ON e.EmployeeID = o.EmployeeID;
    
-- 13
SELECT 
    s.SupplierID,
    s.CompanyName AS SupplierName,
    p.ProductID,
    p.ProductName
FROM Suppliers s
LEFT JOIN Products p
    ON s.SupplierID = p.SupplierID;

-- 14
SELECT 
    c.CustomerID,
    c.CompanyName,
    o.OrderID,
    p.ProductName,
    od.Quantity,
    od.UnitPrice
FROM Customers c
INNER JOIN Orders o
    ON c.CustomerID = o.CustomerID
INNER JOIN `Order Details` od
    ON o.OrderID = od.OrderID
INNER JOIN Products p
    ON od.ProductID = p.ProductID;
-- 15
SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    COUNT(o.OrderID) AS TotalOrders
FROM Employees e
LEFT JOIN Orders o
    ON e.EmployeeID = o.EmployeeID
GROUP BY 
    e.EmployeeID,
    e.FirstName,
    e.LastName
ORDER BY TotalOrders DESC;
 
